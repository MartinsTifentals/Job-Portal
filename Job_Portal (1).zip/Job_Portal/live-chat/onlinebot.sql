-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2026 at 01:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinebot`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_logs`
--

CREATE TABLE `chat_logs` (
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `session_id` varchar(64) NOT NULL,
  `sender` enum('USER','BOT') NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_logs`
--

INSERT INTO `chat_logs` (`id`, `created_at`, `session_id`, `sender`, `message`) VALUES
(1, '2026-02-19 00:25:20', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'BOT', 'Hi! Start: Need help?\nAre you logged in?'),
(2, '2026-02-19 00:25:23', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'USER', '[button] START'),
(3, '2026-02-19 00:25:23', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'BOT', 'Please choose Yes/No using the buttons.'),
(4, '2026-02-19 00:25:33', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'USER', '[button] LOGGED_IN_YES'),
(5, '2026-02-19 00:25:33', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'BOT', 'What do you need help with?'),
(6, '2026-02-19 00:25:43', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'USER', '[button] TOPIC_APPLY'),
(7, '2026-02-19 00:25:43', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'BOT', 'Applying for a job \n\nIs the \'Apply\' button missing / giving an error?'),
(8, '2026-02-19 00:25:50', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'USER', '[button] APPLY_ERR_NO'),
(9, '2026-02-19 00:25:50', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'BOT', 'Help: Track application status / confirm submission.\n\nGo to:\nProfile → My Applications → select job → view status.\n\nSolved?'),
(10, '2026-02-19 00:25:55', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'USER', '[button] SOLVED_YES'),
(11, '2026-02-19 00:25:55', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'BOT', 'End: Glad I could help! \n\nNeed anything else?'),
(12, '2026-02-19 00:25:58', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'USER', '[button] DONE'),
(13, '2026-02-19 00:25:58', 'ac1bd1c997bde9fc7c4d3de883e8fb77', 'BOT', 'Chat closed. Have a good day');

-- --------------------------------------------------------

--
-- Table structure for table `support_tickets`
--

CREATE TABLE `support_tickets` (
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `session_id` varchar(64) NOT NULL,
  `name` varchar(120) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `best_time` varchar(120) NOT NULL,
  `topic` varchar(60) NOT NULL,
  `summary` varchar(255) NOT NULL,
  `status` enum('OPEN','CALLED','CLOSED') DEFAULT 'OPEN'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_logs`
--
ALTER TABLE `chat_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_logs`
--
ALTER TABLE `chat_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
