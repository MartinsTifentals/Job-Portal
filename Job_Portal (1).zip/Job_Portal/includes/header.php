<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>JobMatrix</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;60;700&display=swap" rel="stylesheet">
</head>

<body>
  <header>
    <!-- Menu Toggle Button (Left Side) -->
    <button id="menu-toggle" class="menu-toggle">
      <span class="hamburger-line"></span>
      <span class="hamburger-line"></span>
      <span class="hamburger-line"></span>
    </button>

    <div id="menu-overlay" class="menu-overlay">
      <nav class="menu">
        <!-- Menu Header with Logo -->
        <div class="menu-header">
          <a href="index.php" class="logo">
            <img src="assets/images/logo1.png" alt="logo1">
          </a>
        </div>

        <ul class="menu-list">
          <li class="menu-list-item">
            <a href="#" class="menu-link">
              <span class="eyebrow">01</span>
              <span class="menu-link-heading">Jobs</span>
              <div class="menu-link-bg"></div>
            </a>
          </li>
          <li class="menu-list-item">
            <a href="#" class="menu-link">
              <span class="eyebrow">02</span>
              <span class="menu-link-heading">Categories</span>
              <div class="menu-link-bg"></div>
            </a>
          </li>
          <li class="menu-list-item">
            <a href="live-chat" class="menu-link">
              <span class="eyebrow">03</span>
              <span class="menu-link-heading">Live Chat</span>
              <div class="menu-link-bg"></div>
            </a>
          </li>
          <li class="menu-list-item">
            <a href="#" class="menu-link">
              <span class="eyebrow">04</span>
              <span class="menu-link-heading">FAQ</span>
              <div class="menu-link-bg"></div>
            </a>
          </li>
          <li class="menu-list-item">
            <a href="#" class="menu-link">
              <span class="eyebrow">05</span>
              <span class="menu-link-heading">Settings</span>
              <div class="menu-link-bg"></div>
            </a>
          </li>
        </ul>

        <div class="menu-details">
          <span class="p-small">Socials</span>
          <div class="socials-row">
            <a href="#" class="text-link">Instagram</a>
            <a href="#" class="text-link">LinkedIn</a>
            <a href="#" class="text-link">Twitter</a>
          </div>
        </div>
      </nav>
    </div>


    <div class="logo">JobMatrix</div>
    <nav>
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="profile.php" class="profile-icon">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" fill="#222">
            <path
              d="M12 12c2.7 0 4.9-2.2 4.9-4.9S14.7 2.2 12 2.2 7.1 4.4 7.1 7.1 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z" />
          </svg>
        </a>

      <?php else: ?>
        <a href="login.php" class="login-btn" id="loginBtn">Login</a>
      <?php endif; ?>
    </nav>
  </header>
</body>
<script src="scripts/script.js"></script>

</html>