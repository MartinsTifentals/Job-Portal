<?php
include 'includes/db.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $password = $_POST['password'];
    $repeatPassword = $_POST['repeat-password'];

    if (empty($name) || empty($email) || empty($password) || empty($repeatPassword)) {
        $message = "All fields are required.";
    } elseif ($password !== $repeatPassword) {
        $message = "Passwords do not match.";
    } else {

        $check = "SELECT id FROM users WHERE email='$email'";
        $result = mysqli_query($conn, $check);

        if (mysqli_num_rows($result) > 0) {
            $message = "Email already registered.";
        } else {

            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $query = "INSERT INTO users (name, email, password) 
                      VALUES ('$name', '$email', '$hashed_password')";
            // change the index to wherever we want them to be redirected after logging in
            if (mysqli_query($conn, $query)) {
                header("Location: index.php");
                exit();
            } else {
                $message = "Something went wrong.";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Signup</title>
    <style>
        :root {
            --accent-color: #6c2bd9;
            --accent-hover: #5320a8;
            --base-color: #ffffff;
            --text-color: #222;
            --input-bg: #f8f9fa;
            --input-border: #e5e5e5;
        }

        body {
            margin: 0;
            font-family: Poppins, Segoe UI, sans-serif;
            background: #f8f9fa;
        }

        .auth-container {
            min-height: calc(100vh - 80px);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 20px;
        }


        /* Centered Card Layout */
        .wrapper {
            background: var(--base-color);
            width: 100%;
            max-width: 420px;
            padding: 40px 35px;
            border-radius: 16px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.05);
            text-align: center;
        }

        h1 {
            font-size: 1.6rem;
            margin-bottom: 5px;
        }

        .subtitle {
            font-size: 0.95rem;
            color: #666;
            margin-bottom: 25px;
        }

        /* Form */
        form {
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        form input {
            height: 48px;
            padding: 0 14px;
            border-radius: 8px;
            border: 1.5px solid var(--input-border);
            background: var(--input-bg);
            font-size: 1rem;
            transition: 0.2s ease;
        }

        form input:focus {
            outline: none;
            border-color: var(--accent-color);
            background: #fff;
            box-shadow: 0 0 0 4px rgba(108, 43, 217, 0.12);
        }

        /* Button */
        form button {
            margin-top: 10px;
            height: 48px;
            border: none;
            border-radius: 8px;
            background: var(--accent-color);
            color: white;
            font-weight: 600;
            cursor: pointer;
            transition: 0.2s ease;
        }

        form button:hover {
            background: var(--accent-hover);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(108, 43, 217, 0.25);
        }

        /* Footer Text */
        .auth-footer {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #666;
        }

        .auth-footer a {
            color: var(--accent-color);
            font-weight: 600;
            text-decoration: none;
        }

        .auth-footer a:hover {
            text-decoration: underline;
        }

        /* ERROR MESSAGE */
        .error-message {
            background: #ffe5e5;
            color: #d60000;
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 15px;
            font-size: 0.9rem;
            border: 1px solid #f5c2c7;
        }
    </style>

    <script type="text/javascript" src="javascript/validation.js" defer></script>
</head>

<body id="signup">
    <?php include "includes/header.php" ?>
    <div class="auth-container">
        <div class="wrapper">
            <h1>Create Account</h1>
            <p class="subtitle">Join JobMatrix and start applying</p>

            <?php if (!empty($message)): ?>
                <p class="error-message">
                    <?php echo $message; ?>
                </p>
            <?php endif; ?>

            <form action="signup.php" method="POST">
                <input type="text" name="name" placeholder="Full Name" required>

                <input type="email" name="email" placeholder="Email Address" required>

                <input type="password" name="password" placeholder="Password" required>

                <input type="password" name="repeat-password" placeholder="Repeat Password" required>

                <button type="submit">Sign Up</button>
            </form>

            <div class="auth-footer">
                Already have an account?
                <a href="login.php">Login</a>
            </div>
        </div>
    </div>
</body>